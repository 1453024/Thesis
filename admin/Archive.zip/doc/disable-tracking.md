# DISCLAIMER:

Google Analytics allows us to analyze the usage of Strapi. The aim is to
improve the product and helps us to understand how you interact with the Admin.

Note: The collected data are anonymous and aren't sold to anyone!

If you don't want to share your data with us, you can simply modify the `strapi` object in the package.json as follows:

```json
{
  "strapi": {
    "allowGa": false
  }
}
```
