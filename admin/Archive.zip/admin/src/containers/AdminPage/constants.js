/**
 *
 * AdminPage constants
 *
 */

export const GET_CURR_ENV_SUCCEEDED = 'app/Admin/GET_CURR_ENV_SUCCEEDED';
export const GET_GA_STATUS = 'app/Admin/GET_GA_STATUS';
export const GET_GA_STATUS_SUCCEEDED = 'app/Admin/GET_GA_STATUS_SUCCEEDED';
export const GET_LAYOUT = 'app/Admin/GET_LAYOUT';
export const GET_LAYOUT_SUCCEEDED = 'app/Admin/GET_LAYOUT_SUCCEEDED';
export const GET_STRAPI_VERSION_SUCCEEDED = 'app/Admin/GET_STRAPI_VERSION_SUCCEEDED';
