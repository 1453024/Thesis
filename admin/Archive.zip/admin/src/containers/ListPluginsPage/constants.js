/*
 *
 * ListPluginsPage constants
 *
 */

export const GET_APP_CURRENT_ENV_SUCCEEDED = 'StrapiAdmin/ListPluginsPage/GET_APP_CURRENT_ENV_SUCCEEDED';
export const GET_PLUGINS = 'StrapiAdmin/ListPluginsPage/GET_PLUGINS';
export const GET_PLUGINS_SUCCEEDED = 'StrapiAdmin/ListPluginsPage/GET_PLUGINS_SUCCEEDED';
export const ON_DELETE_PLUGIN_CLICK = 'StrapiAdmin/ListPluginsPage/ON_DELETE_PLUGIN_CLICK';
export const ON_DELETE_PLUGIN_CONFIRM = 'StrapiAdmin/ListPluginsPage/ON_DELETE_PLUGIN_CONFIRM';
export const DELETE_PLUGIN_SUCCEEDED = 'StrapiAdmin/ListPluginsPage/DELETE_PLUGIN_SUCCEEDED';
