/**
*
* Header
*
*/

import React from 'react';
import styles from './styles.scss';

class Header extends React.Component { // eslint-disable-line react/prefer-stateless-function
  render() {
    return (
      <div className={styles.header}>

      </div>
    );
  }
}

export default Header;
