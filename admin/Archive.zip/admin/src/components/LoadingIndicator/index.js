/**
 *
 *
 * LoadingIndicator
 */

import React from 'react';

const LoadingIndicator = () => <div>Loading....</div>;

export default LoadingIndicator;
